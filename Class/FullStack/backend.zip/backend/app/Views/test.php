<?php
foreach ($products as $product) {
    echo $product->product_name . "<br>";
}
